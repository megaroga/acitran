<?php session_start();session_destroy(); ?>

<script language="javascript1.2">window.location.href="<?php echo "login.php"; ?>";</script>

